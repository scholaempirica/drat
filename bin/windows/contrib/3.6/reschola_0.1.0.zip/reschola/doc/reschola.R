## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(reschola)

## -----------------------------------------------------------------------------
# ggplot(mtcars, aes(mpg)) +
#   geom_bar() +
#   scale_x_continuous(expand = flush_y)

