---
title: "Schola-styled Word document"
author: "Schola Empirica"
date: "The Date"
output: reschola::schola_word
---



![](figures/unnamed-chunk-1-1.png){width=2007px}



