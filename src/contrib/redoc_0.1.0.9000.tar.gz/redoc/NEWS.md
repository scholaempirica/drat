# devel

*  Windows `\r\n` line endings are converted to just `\n` in all cases.
   (Fixes #39, h/t @uweremerbollow)

*  Bugfix: `...` arguments in `redoc()` are now passed to 
   rmarkdown::word_document (#35, thanks @scientificbruno)

*  Bugfix: Markdown tables now render correctly (#40, h/t @scientificbruno)

*  Document R Markdown template in RStudio (#32 h/t @maelle, #36, thanks
   @jaystern)

# redoc 0.1.0.9000

* Major refactor for presentation at NY R Conference

# redoc 0.0.0.9000

* Initial commit
