library(testthat)
library(redoc)

test_check("redoc")
