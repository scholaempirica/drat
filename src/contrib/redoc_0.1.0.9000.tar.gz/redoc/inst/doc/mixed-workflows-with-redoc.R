## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
collapse = TRUE,
comment = "#>")

## ----install_me, eval = FALSE-------------------------------------------------
#  remotes::install_github("noamross/redoc")

## ----cleanup1, include = FALSE------------------------------------------------
unlink("example.Rmd")

## ----unrender-----------------------------------------------------------------
library(redoc)
print(basename(redoc_example_docx()))
dedoc(redoc_example_docx())

## ----cleanup2, include = FALSE------------------------------------------------
unlink("example.Rmd")

## ----diff0, eval = FALSE------------------------------------------------------
#  redoc_diff(redoc_example_edited_docx())

