# reschola (development version)

* improved README and added "Getting started" vignette
* basic `theme_schola()` added

# reschola 0.1.0

* foundations of Rmarkdown templates and output format
* foundations of an RStudio project template for project initiation

# reschola 0.0.0.9000

* package basics
* Added a `NEWS.md` file to track changes to the package.
