# Precompiled vignettes that depend on locally installed fonts
# Must then move image files from reschola/ to reschola/vignettes/ after knit

library(knitr)
knit("vignettes/charts.Rmd.orig", "vignettes/charts.Rmd")
pictures <- fs::dir_ls(".", glob = "charts-*.png")
fs::file_move(pictures, new_path = "vignettes")
